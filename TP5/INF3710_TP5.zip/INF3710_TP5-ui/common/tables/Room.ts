export interface Room {
    "hotelno": string;
    "roomno": string;
    "typeroom": string;
    "price": number;
}
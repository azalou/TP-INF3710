export interface Hotel {
    "hotelno": string;
    "hotelname": string;
    "city": string;
}
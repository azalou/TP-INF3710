import { Component, OnInit } from "@angular/core";
import { CommunicationService } from "../communication.service";
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { Owner, Pet } from '../../../../common/tables';

@Component({
  selector: "app-registration",
  templateUrl: "./registration.component.html",
  styleUrls: ["./registration.component.css"]
})


export class RegistrationComponent implements OnInit {

  public ownerForm: FormGroup;
  public petForm: FormGroup;
  public clinicPks: string[] = [];
  public ownerPks: string[] = [];
  public petPks: string[] = [];
  public ownerFiltered: Observable<string[]>;
  public duplicateError: boolean = false;
  public invalidClinicPK: boolean = false;
  public selectedOwnerID: string;
  public currentOwner: Owner;
  public modifyOwner = false;
  public modifyPet = false;
  public showUnlockPet = false;

  public constructor(private communicationService: CommunicationService, private formbuilder: FormBuilder) { }
  ngOnInit() {
    this.ownerForm = this.formbuilder.group({
      actionOwner: ['Search'],
      clinicId: [''],
      ownerId: [''],
      ownerFullName: [''],
      ownerPhone: [''],
      ownerAddress: [''],
      ownerCity: [''],
      ownerState: [''],
      ownerPCode: [''],
      ownerfullAddress: ['']
    });

    this.petForm = this.formbuilder.group({
      petId: [''],
      petName: [''],
      petSpecie: [''],
      petDescription: [''],
      petDOB: [''],
      petStatus: ['']
    });

    this.ownerForm.controls.ownerFullName.disable();
    this.ownerForm.controls.ownerPhone.disable();
    this.ownerForm.controls.ownerfullAddress.disable();
    // Subscription to get clinics Pks
    this.communicationService.getClinicsPK().subscribe((clinicsID: string[]) => {
      this.clinicPks = clinicsID;
    });
    // Subscribtions to monitor form values of Owner Form
    this.ownerForm.controls.clinicId.valueChanges.subscribe(val => {
      this.onSelectedClinic(val);
    });
    this.ownerForm.controls.ownerId.valueChanges.subscribe(val => {
      if (val !== '') {
        if (this.modifyOwner) {
          if (this.ownerForm.controls.actionOwner.value == "Update") {

          }
        } else {
          this.fillOwnerForm(val);
        }
      }
    });
    this.petForm.controls.petId.valueChanges.subscribe(val => {
      if (val !== '') {
        this.fillPetForm(val);
      }
      this.fillPetDetails(val);
    });

    //setting the autocomplete
    this.ownerFiltered = this.ownerForm.controls.ownerId.valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value))
      );
    console.log(this.clinicPks);
    console.log(this.duplicateError);
    this.ownerForm.controls.actionOwner.valueChanges.subscribe(val => {
      switch (val) {
        case "New":
          this.modifyOwner = true;
          this.ownerForm.controls.ownerId.disable();
          this.ownerForm.controls.ownerFullName.enable();
          this.ownerForm.controls.ownerPhone.enable();
          break;
        case "Search":
          this.modifyOwner = false;
          this.ownerForm.controls.ownerFullName.disable();
          this.ownerForm.controls.ownerPhone.disable();
          break;
        case "Update":
          this.modifyOwner = true;
          this.ownerForm.controls.ownerId.enable();
          this.ownerForm.controls.ownerFullName.enable();
          this.ownerForm.controls.ownerPhone.enable();
          break;
        default:
          console.log("shouldn't be here");
          break;
      }
    });
  }
  public updateOwner(): any {
    if (this.ownerForm.controls.actionOwner.value == "Update") {
      var adresse = ''
      console.log("updating owner: " + this.ownerForm.controls.ownerId.value + " in clinic " + this.ownerForm.controls.clinicId.value);
      if (this.ownerForm.controls.ownerAddress.value !== ''){
        adresse = this.ownerForm.controls.ownerAddress.value + " " + this.ownerForm.controls.ownerCity.value + "   "
      + this.ownerForm.controls.ownerState.value + " " + this.ownerForm.controls.ownerPCode.value
      } else {
        adresse = this.ownerForm.controls.ownerfullAddress.value
      }
      
      const uowner: Owner = {
        ownerid: this.ownerForm.controls.ownerId.value,
        cid: this.ownerForm.controls.clinicId.value,
        name: this.ownerForm.controls.ownerFullName.value,
        phone: this.ownerForm.controls.ownerPhone.value,
        address: adresse
      }
      console.log(uowner);
      this.communicationService.updateOwner(uowner).subscribe((val: number) => {
        console.log("Owner updated");
        console.log(val);
      });
    } else if (this.ownerForm.controls.actionOwner.value == "New") {

    }

  }

  public newPet(): void {
    console.log("inserting Pet " + " of: " + this.ownerForm.controls.ownerId.value + " in clinic " + this.ownerForm.controls.clinicId.value);
    let petdob = new Date(this.petForm.controls.petDOB.value);
      const upet: Pet = {
        ownerid: this.ownerForm.controls.ownerId.value,
        cid: this.ownerForm.controls.clinicId.value,
        petid: this.petForm.controls.petId.value,
        name: this.petForm.controls.petName.value,
        specie: this.petForm.controls.petSpecie.value,
        description: this.petForm.controls.petDescription.value,
        dob: petdob,
        status: this.petForm.controls.petStatus.value
      }
      console.log(upet);
      this.communicationService.newPet(upet).subscribe((val: number) => {
        console.log("pet updated");
        console.log(val);
        this.ownerFiltered = this.ownerForm.controls.ownerId.valueChanges
          .pipe(
            startWith(''),
            map(value => this._filter(value))
          );
      });

  }


  public updatePet(): void {
    let petdob = new Date(this.petForm.controls.petDOB.value);
      const upet: Pet = {
        ownerid: this.ownerForm.controls.ownerId.value,
        cid: this.ownerForm.controls.clinicId.value,
        petid: this.petForm.controls.petId.value,
        name: this.petForm.controls.petName.value,
        specie: this.petForm.controls.petSpecie.value,
        description: this.petForm.controls.petDescription.value,
        dob: petdob,
        status: this.petForm.controls.petStatus.value
      }
      console.log(upet);
    if (this.petForm.controls.petId.value != 'new'){
      console.log("updating Pet " + this.petForm.controls.petId.value + " of: " + this.ownerForm.controls.ownerId.value + " in clinic " + this.ownerForm.controls.clinicId.value);
    
      this.communicationService.updatePet(upet).subscribe((res: number) => {
        if (res > 0) {
          this.communicationService.filter("update");
        }
        console.log("failed to update");
        
      });
    } else {
      this.communicationService.newPet(upet).subscribe((res: number) => {
        if (res > 0) {
          this.communicationService.filter("update");
        }
        console.log("failed to update");
        
      });
    }
    

  }

  public deletepet(): void {
    console.log("Deleting Pet ");
    const petKey: any = {
      "ownerid": this.ownerForm.controls.ownerId,
      "cid": this.ownerForm.controls.clinicId.value,
      "petid": this.petForm.controls.petId.value
    };

    if (petKey.ownerid !== '' && petKey.cid !== '' && petKey.petid !== '') {
    this.communicationService.deletePet(petKey).subscribe((val: number) => {
      console.log("pet updated");
      console.log(val);
      this.ownerFiltered = this.ownerForm.controls.ownerId.valueChanges
        .pipe(
          startWith(''),
          map(value => this._filter(value))
        );
    });
  }
  }


  fillPetDetails(val: any): any {
    switch (val) {
      case "new":

        Object.keys(this.petForm.controls).forEach(key => {
          if (key !== "petId") {
            this.petForm.get(key).enable();
          }
        });
        if (this.petForm.controls.petId.value === "new") {
          this.showUnlockPet = false;
        }
        break;

      default:
        Object.keys(this.petForm.controls).forEach(key => {
          if (key !== "petId") {
            this.petForm.get(key).disable();
          }
        });
        this.showUnlockPet = true;
        break;
    }
  }

  public updatingPet(): void {
    if (this.modifyPet) {
      this.modifyPet = false;
      this.fillPetDetails('');
    } else {
      this.modifyPet = true;
      this.fillPetDetails("new");
    }

  }

  public insertOwner(ownerID: string, cID: string, name: string, phone: string, address: string): void {
    const owner: any = {
      "ownerID": ownerID,
      "cID": cID,
      "name": name,
      "phone": phone,
      "address": address
    };

    this.communicationService.insertOwner(owner).subscribe((res: number) => {
      if (res > 0) {
        this.communicationService.filter("update");
      }
      this.duplicateError = (res === -1);
    });
  }

  /**
   * onSelectedClinic
clinic: string : void   */
  public onSelectedClinic(clinicid: string): void {
    console.log("clinic selected");
    console.log(this.ownerForm.value)
    this.communicationService.getOwnerPKFromClinicID(clinicid).subscribe((ownersID: string[]) => {
      this.ownerPks = ownersID;
      console.log("Getting owners list");
      console.log(this.ownerPks);
      this.ownerFiltered = this.ownerForm.controls.ownerId.valueChanges
        .pipe(
          startWith(''),
          map(value => this._filter(value))
        );
    });
  };

  public onSelectedOwner(ownerid: string): void {
    console.log("owner selected");
    console.log(this.ownerForm.value)
    const clinicid: string = this.ownerForm.controls.clinicId.value;
    if (this.ownerPks.indexOf(ownerid) !== -1 && this.ownerPks.indexOf(ownerid) !== -1) {
      console.log("clinicid/ownerid exists");
      this.communicationService.getPetsPKFromOnCID(ownerid, clinicid).subscribe((petsID: string[]) => {
        console.log("getting pets details");
        this.petPks = petsID;
        console.log(this.petPks);
      });
    }
  };

  public fillOwnerForm(ownerid: string): void {
    // si le ID du propriétaire matche un ownerIdID existant on met a jour les champs requis
    console.log("Trying to fill owner details of " + ownerid)
    console.log(this.ownerForm.value)
    const ownerKey: any = {
      "ownerid": ownerid,
      "cid": this.ownerForm.controls.clinicId.value
    };
    console.log(ownerKey);
    if (this.ownerPks.indexOf(ownerid) !== -1) {
      console.log("we have validated the owner exists");
      //Getting Pets of associated owner
      console.log("getting pets details");
      this.communicationService.getPetsPKFromOnCID(ownerKey.ownerid, ownerKey.cid).subscribe((petsPKs: string[]) => {
        console.log("receiving response for pets ids");
        this.petPks = petsPKs;
        console.log(this.petPks);
      });
      //Getting Owner file
      this.communicationService.getOwner(ownerKey).subscribe((theOwner: any[]) => {
        console.log("receiving response for owner details");
        console.log(theOwner);
        
        this.ownerForm.controls.ownerFullName.setValue(theOwner[0].name);
        this.ownerForm.controls.ownerPhone.setValue(theOwner[0].phone);
        var addresse: String; addresse = theOwner[0].address;
        this.ownerForm.controls.ownerfullAddress.setValue(addresse.replace('   ', '\n'));
      });

    }
  };

  public fillPetForm(petid: string): void {
    // si le ID de l'animal matche un petId existant on met a jour les champs requis
    console.log("Trying to fill pet details of " + petid)
    console.log(this.ownerForm.value)
    const petKey: any = {
      "ownerid": this.ownerForm.controls.ownerId.value,
      "cid": this.ownerForm.controls.clinicId.value,
      "petid": petid
    };
    console.log(petKey);
    if (this.petPks.indexOf(petid) !== -1 && this.ownerPks.indexOf(petKey.ownerid) !== -1) {
      console.log("we have validated the pet exists");
      //Getting Owner file
      this.communicationService.getPet(petKey).subscribe((thePet: any[]) => {
        console.log(`response for pet details`);
        console.log(thePet[0]);


        this.petForm.controls.petName.setValue(thePet[0].name);
        this.petForm.controls.petSpecie.setValue(thePet[0].specie);
        this.petForm.controls.petStatus.setValue(thePet[0].status);
        this.petForm.controls.petDescription.setValue(thePet[0].description);
        this.petForm.controls.petDOB.setValue(thePet[0].dob.slice(0, 10));
      });

    }
  };

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.ownerPks.filter(option => option.toLowerCase().includes(filterValue));
  }

}

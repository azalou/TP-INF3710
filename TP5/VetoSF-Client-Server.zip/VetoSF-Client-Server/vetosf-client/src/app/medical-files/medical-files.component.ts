import { Component, OnInit } from '@angular/core';
import { CommunicationService } from '../communication.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';

@Component({
  selector: 'app-medical-files',
  templateUrl: './medical-files.component.html',
  styleUrls: ['./medical-files.component.css']
})
export class MedicalFilesComponent implements OnInit {
  public medicalForm: FormGroup;
  public examForm: FormGroup;
  public treatForm: FormGroup;
  public clinicPks: string[];
  public ownerPks: string[];
  public ownerFiltered: Observable<string[]>;
  public petPks: string[];
  public treatPks: string[];

  public constructor(private communicationService: CommunicationService, private formbuilder: FormBuilder) { }
  public examPks: string[] = [];
  ngOnInit() {
    this.medicalForm = this.formbuilder.group({
      clinicId: [''],
      ownerId: [''],
      petId: ['']
    });

    this.examForm = this.formbuilder.group({
      examId: [''],
      vetName: [''],
      examDescription: [''],
      examDate: [''],
      examTime: ['']
    });

    this.treatForm = this.formbuilder.group({
      treatID: [''],
      treatCost: [''],
      treatQty: [''],
      treatDescription: [''],
      treatStartD: [''],
      treatEndD: [''],
      TreatmentTotal: ['']
    });

    // Subscription to get clinics Pks
    this.communicationService.getClinicsPK().subscribe((clinicsID: string[]) => {
      this.clinicPks = clinicsID;
    });

    // Subscribtions to monitor form values of Medic Form
    this.medicalForm.controls.clinicId.valueChanges.subscribe(val => {
      this.onSelectedClinic(val);
    });
    this.medicalForm.controls.ownerId.valueChanges.subscribe(val => {
      this.onSelectedOwner(val);
    });
    this.medicalForm.controls.petId.valueChanges.subscribe(val => {
      this.lookForExamPKS();
    });
    this.examForm.controls.examId.valueChanges.subscribe(val => {
      this.lookForTreatPKS();
    });
    // On remplis les detais des traitements
    this.treatForm.controls.treatID.valueChanges.subscribe(val => {
      this.fillTreatmentDetails();
      this.fillVeterinaryName();
      this.fillTotalCost();
    });

  }

  public onSelectedClinic(clinicid: string): void {
    console.log("clinic selected");
    console.log(this.medicalForm.value)
    this.communicationService.getOwnerPKFromClinicID(clinicid).subscribe((ownersID: string[]) => {
      this.ownerPks = ownersID;
      console.log("Getting owners list");
      console.log(this.ownerPks);
      this.ownerFiltered = this.medicalForm.controls.ownerId.valueChanges
        .pipe(
          startWith(''),
          map(value => this._filter(value))
        );
    });
  };

  public onSelectedOwner(ownerID: string): void {
    console.log("owner selected");
    console.log(this.medicalForm.value)
    const clinicid: string = this.medicalForm.controls.clinicId.value;
    const ownerid: string = this.medicalForm.controls.ownerId.value;
    if (this.ownerPks.indexOf(ownerid) !== -1 && this.clinicPks.indexOf(clinicid) !== -1) {
      console.log("clinicid/ownerid exists");
      this.communicationService.getPetsPKFromOnCID(ownerID, clinicid).subscribe((petsID: string[]) => {
        console.log("getting pets PKs");
        this.petPks = petsID;
        console.log(this.petPks);
      });
    }
  };



  public lookForExamPKS(): void {
    console.log("looking for exams for pet");
    const clinicid: string = this.medicalForm.controls.clinicId.value;
    const ownerid: string = this.medicalForm.controls.ownerId.value;
    const petid: string = this.medicalForm.controls.petId.value;
    if (this.ownerPks.indexOf(ownerid) !== -1 && this.clinicPks.indexOf(clinicid) !== -1 && this.petPks.indexOf(petid) !== -1)
    {
      console.log("clinicid/ownerid/petid exists");
      //Liste des examens a partir de la clef primaire
      this.communicationService.getExamPks(ownerid, clinicid, petid).subscribe((examspk: string[]) => {
        console.log("getting Exam PKs");
        this.examPks = examspk;
        console.log(this.examPks);
      });

    }
  }

  public lookForTreatPKS(): void {
    console.log("looking for exams for pet");
    const clinicid: string = this.medicalForm.controls.clinicId.value;
    const ownerid: string = this.medicalForm.controls.ownerId.value;
    const petid: string = this.medicalForm.controls.petId.value;
    const examid: string = this.examForm.controls.examId.value;
    if (this.ownerPks.indexOf(ownerid) !== -1 && this.clinicPks.indexOf(clinicid) !== -1 && this.petPks.indexOf(petid) !== -1
    && this.examPks.indexOf(examid) !== -1)
    {
      console.log("clinicid/ownerid/petid/examid exists");
      //Liste des examens a partir de la clef primaire
      this.communicationService.getTreatPks(examid).subscribe((treatspk: string[]) => {
        console.log("getting Treat PKs");
        this.treatPks = treatspk;
        console.log(this.treatPks);
      });
    }
  }

  public fillTreatmentDetails(): void {
    const treatKey: any = {
      "treatid": this.treatForm.controls.treatID.value
    };
    this.communicationService.fillTreatDetails(treatKey).subscribe((theTreatment: any[]) =>{
      console.log("receiving response for treatment details");
      console.log(this.treatForm.controls.treatID.value)
      console.log(theTreatment);
      this.treatForm.controls.treatCost.setValue(parseFloat(theTreatment[0].tcost));
        this.treatForm.controls.treatDescription.setValue(theTreatment[0].description);
        this.treatForm.controls.treatQty.setValue(parseFloat(theTreatment[0].quantity));
        this.treatForm.controls.treatStartD.setValue(theTreatment[0].sdate.slice(0, 10));
        this.treatForm.controls.treatEndD.setValue(theTreatment[0].edate.slice(0, 10));
        
    });
  }


  public fillTotalCost(): void {
    //non implémenté
  }
  public fillVeterinaryName(): void {
    //nom implémenté
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.ownerPks.filter(option => option.toLowerCase().includes(filterValue));
  }

}
